
package SistemaFerreteria;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Martin
 */
public class ModificarClientes extends javax.swing.JFrame {

  private static ModificarClientes instancia;
  private Connection conexion;
  private PreparedStatement ps;
  private ResultSet rs;
  private DefaultTableModel modeloTabla;
  
    public ModificarClientes() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setAlwaysOnTop(true);
        
        modeloTabla = (DefaultTableModel) jTable1.getModel();
        cargarDatosTabla();
    }

    private void cargarDatosTabla() {
        try {
            
           conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/base de datos ferreteria", "root", "");
            String consulta = "SELECT * FROM `clientes`";
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery(consulta);
            modeloTabla.setRowCount(0);
            while (rs.next()) {
                Object[] fila = {
                        rs.getString("Nombre"),
                        rs.getString("Apellido"),
                        rs.getInt("ID Cliente"),
                        rs.getInt("telefono")
                };
                modeloTabla.addRow(fila);
            }

            rs.close();
            stmt.close();
            conexion.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar los datos de la tabla");
        }
    }
    
    private void ModificarCliente() {
    int filaSeleccionada = jTable1.getSelectedRow();
    if (filaSeleccionada != -1) {
        try {
            
            String nombreActual = jTable1.getValueAt(filaSeleccionada, 0).toString();
            String apellidoActual = jTable1.getValueAt(filaSeleccionada, 1).toString();
            int idClienteActual = Integer.parseInt(jTable1.getValueAt(filaSeleccionada, 2).toString());
            String telefonoActual = jTable1.getValueAt(filaSeleccionada, 3).toString();

            
            String nuevoNombre = JOptionPane.showInputDialog(this, "Introduce el nuevo nombre:", nombreActual);
            String nuevoApellido = JOptionPane.showInputDialog(this, "Introduce el nuevo apellido:", apellidoActual);
            String nuevoTelefono = JOptionPane.showInputDialog(this, "Introduce el nuevo teléfono:", telefonoActual);

            if (nuevoNombre != null && nuevoApellido != null && nuevoTelefono != null) {
               
                conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/base de datos ferreteria", "root", "");
                String sql = "UPDATE clientes SET Nombre=?, Apellido=?, telefono=? WHERE `ID Cliente`=?";
                ps = conexion.prepareStatement(sql);
                ps.setString(1, nuevoNombre);
                ps.setString(2, nuevoApellido);
                ps.setString(3, nuevoTelefono);
                ps.setInt(4, idClienteActual);
                ps.executeUpdate();
                ps.close();
                conexion.close();
                cargarDatosTabla();

               
                JOptionPane.showMessageDialog(this, "Cliente modificado correctamente");
            } else {
                JOptionPane.showMessageDialog(this, "No se han ingresado todos los datos");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al modificar el cliente");
        }
    }
}
 
private void EliminarCliente() {
    int filaSeleccionada = jTable1.getSelectedRow();
    if (filaSeleccionada != -1) {
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/base de datos ferreteria", "root", "");
            int idCliente = Integer.parseInt(jTable1.getValueAt(filaSeleccionada, 2).toString());
            String sql = "DELETE FROM `clientes` WHERE `ID Cliente`=?";
            ps = conexion.prepareStatement(sql);
            ps.setInt(1, idCliente);
            ps.executeUpdate();
            cargarDatosTabla();
            ps.close();
            conexion.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al eliminar el cliente");
        }
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jButton1.setText("Modificar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Eliminar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Salir");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel1.setText("Modificar Clientes");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombre ", "Apellido", "ID Cliente", "Telefono"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 569, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addGap(18, 18, 18)
                                .addComponent(jButton2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton3)))
                        .addGap(77, 77, 77))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       instancia = null;
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        instancia = null;
    }//GEN-LAST:event_formWindowClosed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       ModificarCliente();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      EliminarCliente();
    }//GEN-LAST:event_jButton2ActionPerformed

   
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ModificarClientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

   public static ModificarClientes getInstancia27(){
   if(instancia == null) {
       instancia = new ModificarClientes();
       getInstancia27().setVisible(true);
   }
   return instancia; 
}
}

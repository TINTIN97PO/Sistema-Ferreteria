
package SistemaFerreteria;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Martin
 */
public class Modificarproductos extends javax.swing.JFrame {

    private static Modificarproductos instancia; 
    private Connection conexion;
    private DefaultTableModel modeloTabla;
    
    public Modificarproductos() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setAlwaysOnTop(true);
        
        modeloTabla = (DefaultTableModel) jTable1.getModel();
        cargarDatosTabla();
    }

    
    private void cargarDatosTabla() {
        try {
            
           conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/base de datos ferreteria", "root", "");
            String consulta = "SELECT * FROM `productos`";
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery(consulta);
            modeloTabla.setRowCount(0);
            while (rs.next()) {
                Object[] fila = {
                        rs.getString("Nombre Producto"),
                        rs.getString("ID Producto"),
                        rs.getFloat("Precio"),
                        rs.getInt("Stock")
                };
                modeloTabla.addRow(fila);
            }

            rs.close();
            stmt.close();
            conexion.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar los datos de la tabla");
        }
    }
    
    private void eliminarProducto() {
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow != -1) {
            String idProductoStr = (String) jTable1.getValueAt(selectedRow, 1);
            int idProducto = Integer.parseInt(idProductoStr);
            try {
                conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/base de datos ferreteria", "root", "");
                String sql = "DELETE FROM  productos  WHERE `ID Producto` = ?";
                PreparedStatement statement = conexion.prepareStatement(sql);
                statement.setInt(1, idProducto);

                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    JOptionPane.showMessageDialog(this, "Producto eliminado correctamente");
                    cargarDatosTabla();
                }

                statement.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al eliminar producto: " + ex.getMessage(), "Error de eliminación", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            } finally {
                try {
                    if (conexion != null) {
                        conexion.close();
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, selecciona un producto para eliminar", "Selección requerida", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void modificarProducto() {
    int filaSeleccionada = jTable1.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona un producto para modificar");
        return;
    }

    try {
      
        String nombreProductoActual = (String) modeloTabla.getValueAt(filaSeleccionada, 0);
        String idProductoActual = (String) modeloTabla.getValueAt(filaSeleccionada, 1);
        float precioActual = (float) modeloTabla.getValueAt(filaSeleccionada, 2);
        int stockActual = (int) modeloTabla.getValueAt(filaSeleccionada, 3);

       
        String nuevoNombreProducto = JOptionPane.showInputDialog(this, "Introduce el nuevo nombre del producto:", nombreProductoActual);
        String nuevoIdProducto = JOptionPane.showInputDialog(this, "Introduce el nuevo ID del producto:", idProductoActual);
        String nuevoPrecioStr = JOptionPane.showInputDialog(this, "Introduce el nuevo precio del producto:", precioActual);
        String nuevoStockStr = JOptionPane.showInputDialog(this, "Introduce el nuevo stock del producto:", stockActual);

        if (nuevoNombreProducto != null && nuevoIdProducto != null && nuevoPrecioStr != null && nuevoStockStr != null) {
            
            float nuevoPrecio = Float.parseFloat(nuevoPrecioStr);
            int nuevoStock = Integer.parseInt(nuevoStockStr);

            
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/base de datos ferreteria", "root", "");
            String consulta = "UPDATE productos SET `Nombre Producto`=?, `ID Producto`=?, `Precio`=?, `Stock`=? WHERE `ID Producto`=?";
            PreparedStatement stmt = conexion.prepareStatement(consulta);
            stmt.setString(1, nuevoNombreProducto);
            stmt.setString(2, nuevoIdProducto);
            stmt.setFloat(3, nuevoPrecio);
            stmt.setInt(4, nuevoStock);
            stmt.setString(5, idProductoActual);

            
            int filasActualizadas = stmt.executeUpdate();
            if (filasActualizadas > 0) {
                JOptionPane.showMessageDialog(this, "Producto modificado correctamente");
                cargarDatosTabla(); 
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo modificar el producto");
            }

            
            stmt.close();
            conexion.close();

        } else {
            JOptionPane.showMessageDialog(this, "No se han ingresado todos los datos");
        }

    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al modificar el producto");
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Error: asegúrate de ingresar números válidos para precio y stock");
    }
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel1.setText("Modificar Productos");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombre Producto", "ID Producto", "Precio C/u", "Stock"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Float.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText("Eliminar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Salir");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Modificar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 595, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addGap(34, 34, 34)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2))
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        instancia = null;
    }//GEN-LAST:event_formWindowClosed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       instancia = null;
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
     modificarProducto(); 
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     eliminarProducto();
    }//GEN-LAST:event_jButton1ActionPerformed

   
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Modificarproductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

public static Modificarproductos getInstancia26(){
   if(instancia == null) {
       instancia = new Modificarproductos();
       getInstancia26().setVisible(true);
       
   }
   return instancia; 
}
}

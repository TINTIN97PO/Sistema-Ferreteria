
package SistemaFerreteria;

/**
 *
 * @author Martin
 */
public class SistemaFerreteria {

   
    public static void main(String[] args) {
       Logging principal = new Logging();
       principal.setVisible(true);
    }
    
}

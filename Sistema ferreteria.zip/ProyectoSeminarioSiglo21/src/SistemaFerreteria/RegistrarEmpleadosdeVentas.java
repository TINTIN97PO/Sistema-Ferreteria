
package SistemaFerreteria;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.Connection;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Martin
 */
public class RegistrarEmpleadosdeVentas extends javax.swing.JFrame {

    private static RegistrarEmpleadosdeVentas instancia;
    private Connection conexion;
    
    public RegistrarEmpleadosdeVentas() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setAlwaysOnTop(true);
        
       try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/base de datos ferreteria", "root", "");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al conectar a la base de datos: " + ex.getMessage(), "Error de conexión", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
        cargarEmpleados();
        
    }
   
        
    private void cargarEmpleados() {
        try {
            String sql = "SELECT * FROM `empleados`";
            PreparedStatement statement = conexion.prepareStatement(sql);
            ResultSet result = statement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0); 

            while (result.next()) {
                String nombreUsuario = result.getString("Nombre Usuario");
                String contraseña = result.getString("contraseña");
                int idEmpleado = result.getInt("ID Empleado");
                model.addRow(new Object[]{nombreUsuario, contraseña, idEmpleado});
            }

            result.close();
            statement.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar los empleados: " + ex.getMessage(), "Error de carga", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    
    private void agregarEmpleado() {
    try {
        String nombreUsuario = JOptionPane.showInputDialog(this, "Ingrese nombre de usuario:");
        String contraseña = JOptionPane.showInputDialog(this, "Ingrese contraseña:");
        String id = JOptionPane.showInputDialog(this, "Ingrese ID:");
        
        String sql = "INSERT INTO empleados(`Nombre Usuario`, `contraseña`, `ID Empleado`) VALUES (?, ?, ?)";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setString(1, nombreUsuario);
        statement.setString(2, contraseña);
        statement.setString(3, id);
        int rowsInserted = statement.executeUpdate();
        if (rowsInserted > 0) {
            JOptionPane.showMessageDialog(this, "Empleado agregado correctamente");
            cargarEmpleados();
        }

        statement.close();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al agregar empleado: " + ex.getMessage(), "Error de inserción", JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }
}

private void editarEmpleado() {
    int selectedRow = jTable1.getSelectedRow();
    if (selectedRow != -1) {
        String nombreUsuario = JOptionPane.showInputDialog(this, "Editar nombre de usuario:", jTable1.getValueAt(selectedRow, 0));
        String contraseña = JOptionPane.showInputDialog(this, "Editar contraseña:", jTable1.getValueAt(selectedRow, 1));
        int idEmpleado = (int) jTable1.getValueAt(selectedRow, 2);

        if (nombreUsuario != null && contraseña != null) {
            try {
                String sql = "UPDATE empleados SET `Nombre Usuario`=?, `contraseña`=? WHERE `ID Empleado`=?";
                PreparedStatement statement = conexion.prepareStatement(sql);
                statement.setString(1, nombreUsuario);
                statement.setString(2, contraseña);
                statement.setInt(3, idEmpleado);

                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    JOptionPane.showMessageDialog(this, "Empleado actualizado correctamente");
                    cargarEmpleados(); 
                }

                statement.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al actualizar empleado: " + ex.getMessage(), "Error de actualización", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor, selecciona un empleado para editar", "Selección requerida", JOptionPane.WARNING_MESSAGE);
    }
}

private void eliminarEmpleado() {
    int selectedRow = jTable1.getSelectedRow();
    if (selectedRow != -1) {
        int idEmpleado = (int) jTable1.getValueAt(selectedRow, 2);

        try {
            String sql = "DELETE FROM empleados WHERE `ID Empleado`=?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, idEmpleado);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(this, "Empleado eliminado correctamente");
                cargarEmpleados(); 
            }

            statement.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al eliminar empleado: " + ex.getMessage(), "Error de eliminación", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor, selecciona un empleado para eliminar", "Selección requerida", JOptionPane.WARNING_MESSAGE);
    }
}
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel1.setText("Registrar empleados");

        jButton1.setText("Agregar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Eliminar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Editar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Salir");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Nombre usuario", "Contraseña", "ID Empleado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton4))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE))
                .addGap(79, 79, 79))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addGap(63, 63, 63))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    instancia = null; 
    dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        instancia = null;
    }//GEN-LAST:event_formWindowClosed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        agregarEmpleado();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        eliminarEmpleado();
       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      editarEmpleado();
    }//GEN-LAST:event_jButton3ActionPerformed

    
    
    public static void main(String args[]) {
       
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al registrar el driver de MySQL: " + ex.getMessage());
            ex.printStackTrace();
            return;
        }
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistrarEmpleadosdeVentas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

    public static RegistrarEmpleadosdeVentas getInstancia20(){
   if(instancia == null) {
       instancia = new RegistrarEmpleadosdeVentas();
       getInstancia20().setVisible(true);
       
   }
   return instancia; 
}
    
}

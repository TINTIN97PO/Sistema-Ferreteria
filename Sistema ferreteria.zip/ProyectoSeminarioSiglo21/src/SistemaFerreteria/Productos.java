
package SistemaFerreteria;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Martin
 */
public final class Productos extends javax.swing.JFrame {

   private static Productos instancia;
   private Connection conexion;
   private DefaultTableModel modeloTabla;
   
   
    public Productos() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setAlwaysOnTop(true);
        
        
    modeloTabla = (DefaultTableModel) jTableProductos.getModel();
    cargarDatosTabla();
     
    
}
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableProductos = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel1.setText("Productos");

        jTableProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombre Producto", "ID Producto", "Precio C/u", "Stock"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Float.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTableProductos);

        jButton2.setText("Salir");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Hacer venta");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 499, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    instancia = null; 
    dispose(); 
   
    }//GEN-LAST:event_jButton2ActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
       instancia = null;
    }//GEN-LAST:event_formWindowClosed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    
    String idProducto = JOptionPane.showInputDialog(this, "Introduce el ID del producto:");
    if (idProducto == null || idProducto.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Debe introducir un ID de producto válido");
        return;
    }
    
    try {
        conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/base de datos ferreteria", "root", "");
        
        
        String query = "SELECT stock FROM productos WHERE `ID Producto` = ?";
        PreparedStatement pstmtConsulta = conexion.prepareStatement(query);
        pstmtConsulta.setString(1, idProducto);
        ResultSet rs = pstmtConsulta.executeQuery();
        
        if (rs.next()) {
            int stockActual = rs.getInt("stock");
            
            if (stockActual <= 0) {
                JOptionPane.showMessageDialog(this, "No hay stock disponible para este producto");
                return;
            }
            
            
            String nombreProducto = JOptionPane.showInputDialog(this, "Ingrese el nombre del Producto:");
            String nombreCliente = JOptionPane.showInputDialog(this, "Ingrese el nombre del cliente:");
            String apellidoCliente = JOptionPane.showInputDialog(this, "Ingrese el apellido del cliente:");
            String idCliente = JOptionPane.showInputDialog(this, "Ingrese el ID del cliente:");
            
           
            if (nombreCliente == null || nombreCliente.trim().isEmpty() ||
                apellidoCliente == null || apellidoCliente.trim().isEmpty() ||
                idCliente == null || idCliente.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Debe completar todos los datos del cliente");
                return;
            }
            
           
            int nuevoStock = stockActual - 1;
            
            
            String consulta2 = "UPDATE productos SET stock = ? WHERE `ID Producto` = ?";
            PreparedStatement pstmtStock = conexion.prepareStatement(consulta2);
            pstmtStock.setInt(1, nuevoStock);
            pstmtStock.setString(2, idProducto);
            pstmtStock.executeUpdate();
            
           
            String Consulta1 = "INSERT INTO ventas (id_producto, nombre_cliente, apellido_cliente, id_cliente , nombre_producto , fecha_compra) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmtVenta = conexion.prepareStatement(Consulta1 );
            pstmtVenta.setString(1, idProducto);
            pstmtVenta.setString(2, nombreCliente);
            pstmtVenta.setString(3, apellidoCliente);
            pstmtVenta.setString(4, idCliente);
            pstmtVenta.setString(5, nombreProducto);
            pstmtVenta.setObject(6, LocalDateTime.now());
            pstmtVenta.executeUpdate();
            
            
            cargarDatosTabla();
            
            JOptionPane.showMessageDialog(this, "Venta realizada");
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró un producto con ese ID");
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al realizar la venta: " + e.getMessage());
        e.printStackTrace();
    } finally {
        try {
            if (conexion != null) {
                conexion.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

   
   
   

    }//GEN-LAST:event_jButton3ActionPerformed

    private void cargarDatosTabla() {
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/base de datos ferreteria", "root", "");
            String consulta = "SELECT * FROM productos ";
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery(consulta);
            modeloTabla.setRowCount(0);
            while (rs.next()) {
                Object[] fila = {
                    rs.getString("Nombre Producto"),
                    rs.getString("ID Producto"),
                    rs.getFloat("Precio"),
                    rs.getInt("stock")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar los datos de la tabla");
            e.printStackTrace();
        } finally {
            try {
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
   
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Productos().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable jTableProductos;
    // End of variables declaration//GEN-END:variables

public static Productos getInstancia(){
   if(instancia == null) {
       instancia = new Productos();
       getInstancia().setVisible(true);
       
   }
   return instancia; 
}

 }
